# mandelbrot.py
# Lab 9
#
# Name:

# keep this import line...
from cs5png import PNGImage

# start your Lab 9 functions here:
